# encoding: utf-8
require "logstash/JRUBY-6970" if RUBY_PLATFORM == "java"
