# encoding: utf-8
require "logstash/event"
